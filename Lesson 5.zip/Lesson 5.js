class Basket {
    basket = []
    constructor(...items) {
        this.basket.push(...items)
    }

    addProduct(item) {
        this.basket.push(item)
    }

    calcTotalPrice() {
        return this._basket.reduce((result, curItem) => {
            return result + curItem.price
        }, 0)
    }
}

class Item {
    name = ''
    price = 0

    constructor(name, price) {
        this._name = name
        this._price = price
    }
}
const myBasket = new Basket(Item1 = new Item('pc', 35000),
    Item2 = new Item('refregerater', 18000),
    Item3 = new Item('tv', 23000))

const Basket_box = myBasket.basket
const Basket_box_html = document.createElement('div')

Basket_box.forEach(element => {
    const product = Basket_box_html.innerHTML = 'a'
    product.innerText = Item.name
    product.setAttribute('href', `#`)
    const product_price = product.innerHTML = 'div'
    product_name.innerText = Item.price

});

const arr = []
let i = 0
let j = 0
function Chess(arr) {
    if (j < 8) {
        if (i < 8) {
            const fild = document.createElement('div')
            i++;

        } else {
            const br = document.createElement('br')
            j++

        }

    } else {
        break

    }



}